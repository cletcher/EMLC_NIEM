This extremely simple IEPD illustrates the components of a NIEM 3.0
IEPD. It may be used as a starting point by IEPD designers.
